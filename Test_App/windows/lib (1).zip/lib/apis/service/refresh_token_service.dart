import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:school_scout/constants/api_endpoints.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants/encryption_logic.dart';
import '../security/secure_http.dart';

class RefreshTokenService {
  static final _storage = FlutterSecureStorage();
  static bool _isRefreshing = false;

  static Future<bool> refresh() async {
    if (_isRefreshing) return false;
    _isRefreshing = true;

    try {
      final refreshToken = await _storage.read(key: 'refreshToken');
      if (refreshToken == null) return false;

      final dio = Dio();



      final response = await dio.post(
        ApiEndpoints.accessToken,
        data: EncryptionUtils.encrypt(jsonEncode({
          "refreshToken": refreshToken,
          "mobNumber": '9164266003',
        })),
        options: Options(
          headers: {'Content-Type': 'text/plain'},
          validateStatus: (s) => s != null && s < 500,
        ),
      );

      print("===== RAW RESPONSE =====");
      print(response.data);
      print("TYPE => ${response.data.runtimeType}");
      print("========================");

      final encrypted = normalizeEncrypted(response.data);
      final decrypted = EncryptionUtils.decrypt(encrypted);
      final decoded = jsonDecode(decrypted);

      print("===== DECRYPTED =====");
      print(decoded);
      print("=====================");

      if (decoded['statusCode'] == "01") {
        await _storage.deleteAll();
        return false;
      }

      await _storage.write(
          key: 'accessToken', value: decoded['accessToken']);
      await _storage.write(
          key: 'refreshToken', value: decoded['refreshToken']);

      return true;
    } catch (e, st) {
      print("REFRESH ERROR => $e");
      print(st);
      return false;
    } finally {
      _isRefreshing = false;
    }
  }
}
String normalizeEncrypted(dynamic data) {
  if (data is String) {
    return data.replaceAll('"', '').trim();
  }
  if (data is List<int>) {
    return utf8.decode(data);
  }
  return data.toString();
}


