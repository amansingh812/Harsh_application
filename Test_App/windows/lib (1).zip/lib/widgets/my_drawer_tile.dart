import 'package:flutter/material.dart';

class MyDrawerTile extends StatelessWidget{

  //final

  final String text;
  final IconData? icon;
  final void Function()? onTap;
  const MyDrawerTile({super.key,
  required this.text,
  required this.icon,
  required  this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Padding(
      padding: const EdgeInsets.only(left: 25.0),
      child: ListTile(
        title: Text(
          text,
          style: TextStyle(color: Theme.of(context).colorScheme.tertiary),
        ),
        leading: Icon(
          icon,
          color: Theme.of(context).colorScheme.tertiary,
        ),
        onTap: onTap,
      ),
    );
  }
}