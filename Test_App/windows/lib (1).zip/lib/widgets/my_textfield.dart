import 'package:flutter/material.dart';

class MyTextfield extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final bool obsecureText;

  const MyTextfield({
  super.key,
  required this.controller,
  required this.hintText,
  required this.obsecureText,
  });

  @override
  Widget build(BuildContext context){
      return Padding(
        padding:const EdgeInsets.symmetric(horizontal:25.0 ),
        child: TextField(
          controller: controller,
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
             borderSide: BorderSide(color: Theme.of(context).colorScheme.secondary),
            ),
             focusedBorder: OutlineInputBorder(
               //borderSide: BorderSide(color: Theme.of(context).colorScheme.primary),
             ),
            hintText: hintText,
          //  hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary),
          )
          ),
      );
  }
}